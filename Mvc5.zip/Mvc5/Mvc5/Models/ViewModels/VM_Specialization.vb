﻿Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports Mvc5.MyModels
Imports VBLib

Namespace ViewModels
    Public Class SpecializationFull

        <Key>
        Public Property Id As Integer

        Public Property Name As String

    End Class
End Namespace

