Database doesn't seed with JSON File. Errors on Create Work, Security Works, Full Name and Student ID, Google is permitted, mark user is added, position field added
