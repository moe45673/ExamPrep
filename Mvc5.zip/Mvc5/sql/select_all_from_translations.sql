﻿use [DefaultConnection];
select * from Translations;
go

